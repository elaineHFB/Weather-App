// You can add as many hard-coded locations here.
// Don't exactly need the unique ids, but just as a counter.

export const locations = [
    {
        "id": 1,
        "location": "Amsterdam",
    },
    {
        "id": 2,
        "location": "Berlin",
    },
    {
        "id": 3,
        "location": "Copenhagen",
    },
    {
        "id": 4,
        "location": "Durham",
    },
    {
        "id": 5,
        "location": "Edmonton",
    },
    {
        "id": 6,
        "location": "Fuji",
    },
    {
        "id": 7,
        "location": "Glasgow",
    },
    {
        "id": 8,
        "location": "Helsinki",
    },
    // {
    //     "id": 9,
    //     "location": "Istanbul",
    // },
    // {
    //     "id": 10,
    //     "location": "Jakarta",
    // },
    // {
    //     "id": 11,
    //     "location": "Kilimanjaro",
    // },
]